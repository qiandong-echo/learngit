package extensions

import org.gradle.api.Project

/**
 * author: yueyang
 * date: 2017.9.14
 * e-mail: hi.yangyue1993@gmail.com
 */
public class FileOutputExtensions {
    def fileOutputName

    public FileOutputExtensions(Project project) {

    }
}
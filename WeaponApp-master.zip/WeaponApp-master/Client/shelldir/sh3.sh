#!/usr/bin/env bash
./gradlew cleanBundle
#!/usr/bin/env bash
./gradlew cleanLib
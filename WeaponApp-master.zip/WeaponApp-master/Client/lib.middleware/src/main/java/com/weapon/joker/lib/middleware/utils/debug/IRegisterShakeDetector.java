package com.weapon.joker.lib.middleware.utils.debug;

import java.util.Map;

/**
 * author : yueyang
 * date : 25/09/2017
 */
public interface IRegisterShakeDetector {
    void registerShakeDetector(final Map<String, Object> map);
}

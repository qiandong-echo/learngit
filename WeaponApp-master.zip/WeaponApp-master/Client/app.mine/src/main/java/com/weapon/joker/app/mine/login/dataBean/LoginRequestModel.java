package com.weapon.joker.app.mine.login.dataBean;

/**
 * author : yueyang
 * date : 2017/10/15
 */
public class LoginRequestModel {

    public String name;
    public String password;

}

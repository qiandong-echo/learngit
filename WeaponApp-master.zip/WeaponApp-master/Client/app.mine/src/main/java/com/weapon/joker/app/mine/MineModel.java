package com.weapon.joker.app.mine;


/**
 * MineModel 我的界面 model
 * author:张冠之
 * time: 2017/9/24 下午4:32
 * e-mail: guanzhi.zhang@sojex.cn
 */

public class MineModel extends MineContact.Model{

}

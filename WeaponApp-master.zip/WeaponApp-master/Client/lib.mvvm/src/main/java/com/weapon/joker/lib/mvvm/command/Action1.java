package com.weapon.joker.lib.mvvm.command;

/**
 * Created by foxleezh on 2017/9/1.
 */

public interface Action1<T>{
    void call(T t);
}
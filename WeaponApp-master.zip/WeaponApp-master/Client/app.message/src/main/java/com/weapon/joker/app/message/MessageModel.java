package com.weapon.joker.app.message;

/**
 * MessageModel 消息Model
 * author:张冠之
 * time: 2017/10/12 下午1:53
 * e-mail: guanzhi.zhang@sojex.cn
 */

public class MessageModel extends MessageContact.Model{


}

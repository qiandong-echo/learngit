package com.weapon.joker.app.message.group;

/**
 * class：   Client
 * author：  xiaweizi
 * date：    2017/10/22 11:57
 * e-mail:   1012126908@qq.com
 * desc:
 */
public class GroupModel extends GroupContact.Model {
}

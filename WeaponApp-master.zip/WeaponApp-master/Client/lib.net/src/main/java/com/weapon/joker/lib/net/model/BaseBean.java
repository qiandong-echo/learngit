package com.weapon.joker.lib.net.model;

import java.io.Serializable;


public class BaseBean implements Serializable {
}

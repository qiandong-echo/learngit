package com.weapon.joker.lib.net.bean.HomeBean;

import com.weapon.joker.lib.net.model.BaseBean;

import java.util.ArrayList;

public class RecommandModel extends BaseBean{

    public ArrayList<RecommandBodyValue> list;
    public RecommandHeadValue head;

}

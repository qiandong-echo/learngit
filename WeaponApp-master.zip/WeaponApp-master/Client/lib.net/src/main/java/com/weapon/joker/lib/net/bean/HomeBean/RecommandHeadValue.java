package com.weapon.joker.lib.net.bean.HomeBean;

import com.weapon.joker.lib.net.model.BaseBean;

import java.util.ArrayList;

public class RecommandHeadValue extends BaseBean {

    public ArrayList<String> ads;
    public ArrayList<String> middle;
    public ArrayList<RecommandFooterValue> footer;

}

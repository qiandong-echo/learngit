package com.weapon.joker.lib.net.bean.HomeBean;

import com.weapon.joker.lib.net.model.BaseResModel;

/**
 * HomeBean 首页数据
 * author:张冠之
 * time: 2018/2/22 上午11:28
 * e-mail: guanzhi.zhang@sojex.cn
 */
public class HomeBean extends BaseResModel<RecommandModel>{
}

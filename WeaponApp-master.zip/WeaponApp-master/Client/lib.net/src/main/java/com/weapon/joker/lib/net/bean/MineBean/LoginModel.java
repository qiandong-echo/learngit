package com.weapon.joker.lib.net.bean.MineBean;

import com.weapon.joker.lib.net.bean.CommonBean.UserBean;
import com.weapon.joker.lib.net.model.BaseResModel;

/**
 * <pre>
 *     author : xiaweizi
 *     class  : com.weapon.joker.lib.net.model.LoginModel
 *     e-mail : 1012126908@qq.com
 *     time   : 2017/10/12
 *     desc   : 登录 model
 * </pre>
 */

public class LoginModel extends BaseResModel<UserBean> {
}

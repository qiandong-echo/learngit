package com.weapon.joker.lib.net.bean.HomeBean;

import com.weapon.joker.lib.net.model.BaseBean;

public class RecommandFooterValue extends BaseBean {

    public String title;
    public String info;
    public String from;
    public String imageOne;
    public String imageTwo;
    public String destationUrl;
}

package com.weapon.joker.lib.net.event;

/**
 * <pre>
 *     author : xiaweizi
 *     class  : com.weapon.joker.lib.net.event.PushNewsEvent
 *     e-mail : 1012126908@qq.com
 *     time   : 2017/10/18
 *     desc   : 推送消息的 Event
 * </pre>
 */

public class PushNewsEvent {}

package com.weapon.joker.lib.net.bean.HomeBean;

public class RecommandMonitorModel {

    public String ver;
    public String url;
    public int time;
}
